package com.example.myapplication.models

data class User(
    val _v:Int,
    val _id:String,
    val createdAt:String,
    val email:String,
    val userName:String,
    val updatedAt:String,
    val password:String)