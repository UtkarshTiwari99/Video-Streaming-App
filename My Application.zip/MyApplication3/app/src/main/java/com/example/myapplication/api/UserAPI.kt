package com.example.myapplication.api

interface UserAPI {

}